from django.apps import AppConfig


class ShauxConfig(AppConfig):
    name = 'shaux'
